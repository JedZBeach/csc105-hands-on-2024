import React from "react";

const SignUpPage = () => {
  return (
    <>
    <h2>SignUpPage</h2>
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTf2dhQmW6KJ-e6XbkjceH3JC_rS27X3d_VXA&s"/>
    </>
);
  
};

export default SignUpPage;