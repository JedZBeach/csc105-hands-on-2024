import React from 'react'

const HomePage = () => {
    return  (
      <>
      <h2>Welcome to the Home </h2>
      <img src="https://i.namu.wiki/i/oaaxBnGPC8tiJM7kp9WMJlQZn0OiZ_-nxOKtQKC1bHCabc9EIM6pNnaZDgaYQA4d3x_tPDACtI-QzLZZggvhHQ.webp"/>
      </>
  );
    
  };
  
  export default HomePage;