```
npm install
npm run dev
```

```
open http://localhost:3000
```
